package com.educaspring.EducaSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
