package com.educaspring.EducaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducaSpringApplication.class, args);
	}

}
